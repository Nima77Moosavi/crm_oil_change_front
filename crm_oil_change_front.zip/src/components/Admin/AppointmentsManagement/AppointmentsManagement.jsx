// AppointmentsManagement.jsx
const AppointmentsManagement = () => {
  return (
    <div>
      <h2>مدیریت نوبت‌ها</h2>
      <p>اینجا لیست و مدیریت نوبت‌ها نمایش داده می‌شود.</p>
    </div>
  );
};

export default AppointmentsManagement;