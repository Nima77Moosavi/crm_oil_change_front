// InventoryManagement.jsx
const InventoryManagement = () => {
  return (
    <div>
      <h2>مدیریت موجودی</h2>
      <p>اینجا لیست و مدیریت موجودی نمایش داده می‌شود.</p>
    </div>
  );
};

export default InventoryManagement;