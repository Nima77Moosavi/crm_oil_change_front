// ServicesManagement.jsx
const ServicesManagement = () => {
  return (
    <div>
      <h2>مدیریت خدمات</h2>
      <p>اینجا لیست و مدیریت خدمات نمایش داده می‌شود.</p>
    </div>
  );
};

export default ServicesManagement;